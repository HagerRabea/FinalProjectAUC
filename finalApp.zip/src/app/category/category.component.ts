import { CommonModule } from '@angular/common';
import { DataService } from './../data.service';
import { Component } from '@angular/core';

@Component({
  selector: 'app-category',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './category.component.html',
  styleUrl: './category.component.css'
})
export class CategoryComponent {
  categories:string[]=[];
  constructor(private _DataService:DataService){
    this._DataService.getCategory().subscribe((x)=>{
      this.categories=x;
      console.log(x)
    })
  }

  
}
