import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private _HttpClient:HttpClient) { }

  //API >>
  /*
HttpClient Module
httpclient >>>
>>methods

  get 
  post
  put
  patch
  delete
  */

 getCategory():Observable<any>{
  let response=this._HttpClient.get('https://dummyjson.com/products/category-list');
  return response;
 }
}
